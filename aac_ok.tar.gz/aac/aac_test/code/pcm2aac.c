#include <faac.h>
#include <stdio.h>

typedef unsigned long   ULONG;
typedef unsigned int    UINT;
typedef unsigned char   BYTE;
typedef char            _TCHAR;

int main(int argc, _TCHAR* argv[])
{
    ULONG nSampleRate = 11025;  
    UINT nChannels = 1;         
    UINT nPCMBitSize = 16;    
    ULONG nInputSamples = 0;
    ULONG nMaxOutputBytes = 0;
	int i = 0;
    int nRet;
    faacEncHandle hEncoder;
    faacEncConfigurationPtr pConfiguration; 

    int nBytesRead;
    int nPCMBufferSize;


    FILE* fpIn; // PCM file for input
    FILE* fpOut; // AAC file for output

    fpIn = fopen(argv[1], "rb");
    fpOut = fopen(argv[2], "wb");

    // (1) Open FAAC engine
    hEncoder = faacEncOpen(nSampleRate, nChannels, &nInputSamples, &nMaxOutputBytes);
    if(hEncoder == NULL)
    {
        printf("[ERROR] Failed to call faacEncOpen()\n");
        return -1;
    }

    nPCMBufferSize = nInputSamples * nPCMBitSize / 8;
	printf("nInputSamples:%d nPCMBufferSize:%d nMaxOutputBytes:%d\n", nInputSamples, nPCMBufferSize,nMaxOutputBytes);

	
    char pbPCMBuffer[nPCMBufferSize+1024];
    char pbAACBuffer[nMaxOutputBytes+1024];


    pConfiguration = faacEncGetCurrentConfiguration(hEncoder);

	pConfiguration->mpegVersion = 4;
    pConfiguration->inputFormat = FAAC_INPUT_16BIT;
	pConfiguration->outputFormat=1;
	pConfiguration->useTns=1;
	pConfiguration->useLfe=0;
	pConfiguration->aacObjectType=LOW;
	pConfiguration->shortctl=SHORTCTL_NORMAL;
	pConfiguration->quantqual=10;
	pConfiguration->bandWidth=0;
	pConfiguration->bitRate=0;

    nRet = faacEncSetConfiguration(hEncoder, pConfiguration);


    for(i = 0; 1; i++)
    {

        nBytesRead = fread(pbPCMBuffer, 1, nPCMBufferSize, fpIn);

        nInputSamples = nBytesRead / (nPCMBitSize / 8);

        nRet = faacEncEncode(hEncoder, (int*) pbPCMBuffer, nInputSamples, pbAACBuffer, nMaxOutputBytes);
       
        fwrite(pbAACBuffer, 1, nRet, fpOut);

        printf("%d: faacEncEncode returns %d\n", i, nRet);

        if(nBytesRead <= 0)
        {
            break;
        }
    }

    nRet = faacEncClose(hEncoder);

    fclose(fpIn);
    fclose(fpOut);

    return 0;
}

